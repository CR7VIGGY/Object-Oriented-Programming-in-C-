//9. Create employee bio-data using following classes i) Personal record ii))Professional  
//record iii) Academic record Assume appropriate data members and member function  
//to accept required data & print bio-data. Create bio-data using multiple inheritance  
//using C++.
//HYBRID INHERITANCE
#include<bits/stdc++.h>
using namespace std;

class Personal
{
	public :
			string name;
			int age;
			string stat;
		void getdata()
		{
			
			cout<<"enter your name\n";
			cin>>name;
			cout<<"enter your age\n";
			cin>>age;
			cout<<"enter your marital status\n";
			cin>>stat;
		}
};
class Proff: virtual public Personal
{
	public :
		string occup;
		void enter()
		{
			
			cout<<"enter your occupation\n";
			cin>>occup;
		}
};
class Acad : virtual public Personal
{
	public :
		float a,b;
		void get()
		{
			
			cout<<"enter your 10 sgpa\n";
			cin>>a;
			cout<<"enter your 12 %age\n";
			cin>>b;
		}
		
};
class Biodata : public Proff , public Acad
{
	public :
		void putdata()
		{
			cout<<"NAME\tAGE\tSTATUS\tOCCUPATION\t10 GRADE\t12 GRADE\n";
			cout<<name<<"\t"<<age<<"\t"<<stat<<"\t"<<occup<<"\t\t"<<a<<"\t"<<b<<"\n";
		}	
};
int main()
{
	Biodata obj;
	obj.getdata();
	obj.enter();
	obj.get();
	obj.putdata();
	return 0;
}
