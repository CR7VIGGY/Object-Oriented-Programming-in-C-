#include<bits/stdc++.h>
using namespace std;
#include<fstream>
#include<conio.h>
#include<string.h>

int main()
{
	ofstream out;
	out.open("name.dat");
	out<<"vighnesh\n";
	out<<"IT\n";
	out<<"4252\n";
	getch();
	return 0;
}
