#include<iostream>
using namespace std;
#include<string.h>

class personal
{
	protected :
		int date;
		string 	name;
		string blood;
		personal()
		{
			
		}
		personal(int d,string s1 , string s2)
		{
			date = d;
			name = s1;
			blood = s2;
		}	
};

class health
{
	protected :
		float h , w;
		health()
		{
			
		}
		health(int x,int y)
		{
			h = x;
			w = y; 
		}
			
};

class address
{
	protected :
		int policy;
		string add;
		address()
		{
			
		}
		address(int z,string s3)
		{
			policy = z;
			add = s3;
		}
};

class derived : protected personal , protected health , protected address
{
	public :
		int m,n;//m = tele, n = driving license no.
		derived()
		{
			
		}
		derived(int date,string name, string blood , int h , int w ,int policy ,string add,int tele , int dlic) : personal(date,name ,blood) , health(h,w) , address(policy,add)
		{
			m = tele;
			n = dlic;
		}
		void editdata(int,int);
		void putdata();
		void remove(int);
};
void derived :: putdata()
{
	
	cout<<name<<"\t";
	cout<<date<<"\t\t";
	cout<<blood<<"\t\t";
	cout<<h<<"\t\t";
	cout<<w<<"\t\t";
	cout<<policy<<"\t\t";
	cout<<add<<"\t";
	cout<<m<<"\t\t";
	cout<<n<<"\t\n";
}
void derived :: editdata(int q,int indx)
{
	int i;
	
	    //input the data 
		cout<<"ENTER DOB AS DDMMYYYY\n";
		cin>>date;
		
		cout<<"ENTER NAME\n";
		cin>>name;
		
		cout<<"ENTER YOUR BLOOD GROUP\n";
		cin>>blood;
		
		cout<<"ENTER YOUR HEIGHT\n";
		cin>>h;
		
		cout<<"ENTER YOUR WEIGHT\n";
		cin>>w;
		
		cout<<"ENTER YOUR INSURANCE POLICY NUMBER\n";
		cin>>policy;
		
		cout<<"ENTER YOUR ADDRESS\n";
		cin>>add;
		
		cout<<"ENTER TELEPHONE NO.\n";
		cin>>m;
		
		
		//creating dynamic object
		
		derived(date,name,blood,h,w,policy,add,m,n); 
    
}
void derived :: remove(int q)
{
	if(q == n)
	{
	//	delete(p[q]);
		//p[q] = p[q+1];
	}
}



int main()
{
	int i,j,k,date,h,w,policy,m,n;
	string name,blood,add;
	int indx = 0;
	char opt;
	int q;
	int a = 0;
	int x[a];
	derived *p[50];
	//derived d;
	cout<<"=======================================\n";
	cout<<"\tWELCOME TO MAIN MENU\n";
	cout<<"=======================================\n";
	
	do
	{
		LOOP:cout<<"PRESS 1 : ENTER DATA\nPRESS 2 : TO DISPLAY ALL DATA\nPRESS 3 : INSERT NEW ENTRY\nPRESS 4 : TO EDIT DATA\nPRESS 5 : TO DELETE ENTRY\nPRESS 6 : TO SEARCH ENTRY\nNPRESS 7 : EXIT";
		cin>>m;
		
		switch(m)
		{
			case 1 ://creating dynamic objects array
					
			LOOPA :	cout<<"DO YOU WANT ENTER ANY ENTRY y/n";
					cin>>opt;
					if(opt == 'y')
					{
						indx++;
					}
					else
					{
						goto LOOP;
					}
				    
					//input the data 
					cout<<"ENTER DOB AS DDMMYYYY\n";
					cin>>date;
					
					cout<<"ENTER NAME\n";
					cin>>name;
					
					cout<<"ENTER YOUR BLOOD GROUP\n";
					cin>>blood;
					
					cout<<"ENTER YOUR HEIGHT\n";
					cin>>h;
					
					cout<<"ENTER YOUR WEIGHT\n";
					cin>>w;
					
					cout<<"ENTER YOUR INSURANCE POLICY NUMBER\n";
					cin>>policy;
					
					cout<<"ENTER YOUR ADDRESS\n";
					cin>>add;
					
					cout<<"ENTER TELEPHONE NO.\n";
					cin>>m;
					
					cout<<"ENTER DRIVING LICENSE NO.\n";
					cin>>n;
					
					//creating dynamic object
					p[indx] = new derived(date,name,blood,h,w,policy,add,m,n); 
					
					break;
									
			case 2 : cout<<"///////DISPLAYING ALL RECORDS///////\n"; 
					 cout<<"NAME\t\tDATE OF BIRTH\tBLOOD GROUP\tHEIGHT\tWEIGHT\tPOLICY NO.\tADDRESS\tTELEPHONE NO.\tDRIVING LIC. NO.\n";
					for(i = 1 ; i <= indx ; i++)
					p[i]->putdata();break;
					
			case 3 : goto LOOPA;break;
			
			case 4 : cout<<"ENTER THE DRIVING LIC. NO.OF THE DATA WHICH HAS TO BE EDITED";
					 cin>>q;
					 p[q]->editdata(q,indx);
					 break;
			case 5 : cout<<"ENTER THE DRIVING LIC. NO. OF DATA WHICH HAS TO BE DELETED";
					 cin>>q;
					 p[q]->remove(q);
					 break;
					 
			case 6 : ;break;
			case 7 : ;break;
		}
	}while(m != 7);
	
	return 0;
}
