//INHERITANCE (SINGLE )
#include<bits/stdc++.h>
#include<string.h>
using namespace std;

class sample
{
	public :
	int x,y;
//	private :
	int z;
//	public:
	void getdata();	
};
void sample::getdata()
{
	cout<<"enter x,y,z";
	cin>>x>>y>>z;
}
class single : public sample
{
	public:
	void putdata()
	{
		cout<<x<<y<<z;
	}
};

int main()
{
	sample s1;
	single s2,*ptr;//child claas ke object  se hi hum oarent class ke member function ko access krr skte hh
	ptr = &s2;
	
	ptr->getdata();//this operator used
	ptr->putdata();
	return 0;
}
