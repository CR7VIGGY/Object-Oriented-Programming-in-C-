//constructor in derived class
#include<bits/stdc++.h>
#include<string.h>
using namespace std;

class alpha
{
	public :
		int x;
		alpha(int i)
		{
			x = i;
		}
		void show_x()
		{
			cout<<x;
		}
		
};
class beta
{
	public:
		int y;
		beta(int j)
		{
			y = j;
		}
		void show_y()
		{
			cout<<y;
		}
		
};
class gamma : public alpha , public beta
{
	public :
		int z;
		gamma(int a,int b,int c):alpha(a),beta(b)
		{
			 z = c;
		}
		void show_z()
		{
			cout<<z;
		}
		
};

int main()
{
	int a,b,c;
	cout<<"enter a,b,c";
	cin>>a>>b>>c;
	gamma G(a,b,c),*p;
	p = &G;
	//p->gamma(a,b,c);
	p->show_x();
	p->show_y();
	p->show_z();
	getchar();
	return 0;
	
}
