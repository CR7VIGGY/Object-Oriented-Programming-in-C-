//QUES ).create a class name wheather report that hold daily wheather report with data members day of month high temp,low temp,amount of snow,rain,use diff. 
//types of constructors to intializethe object also nclude a function that prompt the user and set values for each field so that u can over write the 
//default value . write a menu driven progg. withn option to enter data and generate maonthly report that display the address of each ?
//VIGHNESH TIWARI , 4252 , ARMY INSTITUTTE OF TECHNOLOGY , PUNE , INDIA
#include<bits/stdc++.h>                     //GITHUB PROFILE : CR7 VIGGY
using namespace std;

class wheather
{
	int i,hight,lowt,rain,snow;
	public:
		wheather()                     //constructor formation
		{
			int hight=100,lowt=0,rain=20,snow=0;
		}
	
	static float avgh,avgl,avgr,avgs;
	
	public:
	
	void getdata();
	void putdata(int n);
	int deldata(int o);
	void avg(int count);
	int check(int x);
	void lol();
	
};
float wheather :: avgh;
float wheather :: avgl;
float wheather :: avgr;
float wheather :: avgs;

void wheather :: getdata()
{
			cout<<"Enter the following details\nHIGH TEMPERATURE\nLOW TEMPERATURE\nRAIN\nSNOW\n";
			cin>>hight>>lowt>>rain>>snow;
			//sum of all entries
			avgh = avgh+hight;
			avgl = avgl+lowt;
			avgr = avgr+rain;
			avgs = avgs+snow;
			
			
	//return (avgh,avgl,avgr,avgs);
}

void  wheather :: putdata(int n )
{
	
	cout<<n<<"\t"<<hight<<"\t\t\t"<<lowt<<"\t\t"<<rain<<"\t"<<snow<<"\n";
	
}

int  wheather :: deldata(int o)
{
			avgh = avgh-hight;
			avgl = avgl-lowt;
			avgr = avgr-rain;
			avgs = avgs-snow;
	hight = 0;
	lowt = 0;
	rain = 0;
	snow = 0;
	o = o-1;
	return (o);
}

void wheather :: avg(int o)
{
	int n = o;
	avgh = avgh/n;
	avgl = avgl/n;
	avgr = avgr/n;
	avgs = avgs/n;
	cout<<"AVERAGE :\t"<<avgh<<"\t\t"<<avgl<<"\t\t"<<avgr<<"\t"<<avgs<<"\n";
}


int main()
{
	int x,m,i,c,n,count = 0,flag=0,flag1 =0,flag2=0,flag4 = 0,chk = 0;
    int o = 0 ;
    int z[o];
	
	wheather w[32];
	do
	{
		cout<<"PRESS 1 : ENTER DAY\nPRESS 2 : GO TO MAIN MENU\n";
		cin>>c;
	
		switch(c)
		{
			case 1 : 
			cout<<".......ENTER YOUR DAY (1-31)........\n";
			cin>>x;	
			
			if(o == 0)
			{
				z[o] = x;
				o = 1;goto LOOP;
			}
			if(o != 0)
			{
				for(i = 0 ; i < o ; i++)
				{
					if(x != z[i])
					{
						z[o] = x;
						o++;
						goto LOOP;
					}
					else
					{
						cout<<"DAY ENTERED ALREADY EXIST\n";break;
					}
				}
			}
			
		LOOP :	
				if(x>31&&x<1)
			cout<<"!!!!ENTER VALID DAY ONLY!!!!\n";
			break;
			
			case 2 : 
			cout<<"PRESS 1 : ENTER DATA\nPRESS 2 : DISPLAY DATA\nPRESS 3 : EDIT DATA\nPRESS 4 : TO DELETE DATA\nPRESS 5 : AVERAGE OF ENTERED DATA\nPRESS 6 : SHOW ALL DATA\nPRESS 7 : EXIT \n";
			cin>>m;
			
			switch(m)
			{
				case 1 : w[x].getdata();break;
			
				case 2 : cout<<"ENTER THE DAY TO BE DISPLAYED\n";
							cin>>n;
							/*for(i = 0 ; i < o ; i++)
							cout<<z[i];*/
							for(i = 0 ; i < o ; i++)
							{   //cout<<z[i]<<"\n";
								if(n == z[i])
								{
									cout<<"DAY\tHIGH TEMPERATURE\tLOW TEMPERATURE\tRAIN\tSNOW\n";
									w[n].putdata(n);
									goto LOOP1;
								}
								else
								flag=1;
								
							}
							if(flag == 1)
								cout<<"INVALID DAY ENTERED\n";
						LOOP1:	break;
				
				case 3 : cout<<"ENTER WHICH DAY DATA TO BE EDITED\n";
						 cin>>n;
						 for(i = 0 ; i < o ; i++)
						 {
							 	if(n == z[i])
							 	{
							 		w[n].getdata();	goto LOOP2;
							 	}
							 	else
							 	flag1 =1;	
						 }
						 if(flag1 == 1)
						 cout<<"INVALID DAY ENTERED\n";
						
						LOOP2:break;
				case 4 : cout<<"ENTER WHICH DAY DATA IS TO BE DELETED\n";
						 cin>>n;
						 for(i = 0 ; i < o  ;i++)
						 {
						 	if(n == z[i])
						 {
						 	o = w[n].deldata(o);
						 	flag4++;
						 	
							 goto LOOP3;
						 }
						 else
						 flag2= 1;
						 }
						 if(flag2 == 1)
						 cout<<"INVALID DAY ENTERED\n";
					LOOP3:	break;
				case 5 : cout<<"ENTER THE DAY FOR AVERAGE\n";
						// cin>>n;
						 cout<<"DAY\tHIGH TEMPERATURE\tLOW TEMPERATURE\tRAIN\tSNOW\n";
						 w[o].avg(o);
						 
					     break;
			
				case 6 : cout<<"DAY\tHIGH TEMPERATURE\tLOW TEMPERATURE\tRAIN\tSNOW\n";
						 o = o+flag4;
							for(i = 1 ; i <= o ; i++)
							w[i].putdata(i);
							break;
				
				case 7 : ;break;
			}
			break;
		}
	}
	while(m !=7);
	
	return 0;
}
