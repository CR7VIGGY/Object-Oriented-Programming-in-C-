//Assgn 2
#include<bits/stdc++.h>
using namespace std;

class Book
{
	public :
		string tit,auth,pub;
		int price,stock;
		
		Book(string title,string author,string publisher,int prc,int stk)
		{
			tit = title;
			auth = author;
			pub = publisher;
			price = prc;
			stock = stk;
		}
		
		
		void putdata(int a)
		{
			
			cout<<(a+1)<<"\t"<<tit<<"\t"<<auth<<"\t"<<pub<<"\t\t"<<price<<"\t"<<stock<<"\n";
		}
		
		void del()
		{
			
		}	
		
};

int main()
{
	Book *b[50];
	int m,n=0,i=0,x;
	string tit,auth,pub;
	int price,stock;
	do
	{
		cout<<"PRESS 1:ADD A BOOK\nPRESS 2:DISPLAY ALL ENTRIES\nPRESS 3:TO UPDATE\nPRESS 4:SEARCH\nPRESS 5:PURCHASE\nPRESS 6:SUCCESSFULL/UNSUCCESSFULL TRANSACTIONS\nPRESS 7:EXIT\n";
	    cin>>m;
		switch(m)
		{
			case 1 : 	cout<<"ENTER BOOK TITLE ";
						cin>>tit;
						cout<<"\n";
						cout<<"ENTER BOOK AUTHOR ";
						cin>>auth;
						cout<<"\n";
						cout<<"ENTER BOOK PUBLISHER ";
						cin>>pub;
						cout<<"\n";
						cout<<"ENTER BOOK PRICE ";
						cin>>price;
						cout<<"\n";
						cout<<"ENTER AVAILABLE STOCK ";
						cin>>stock;
						cout<<"\n";
			         	b[n] = new Book(tit,auth,pub,price,stock);
			         	n++;
						break;
			case 2 : cout<<"S.NO.\tTITLE\tAUTHOR\tPUBLISHER\tPRICE\tAVAILABLE STOCK\n";
				        while(i<n)
						{
							b[i]->putdata(i);
							i++;
						}
						break;
			case 3 :
					cout<<"ENTER THE SERIAL NO. OF THE BOOK TO UPDATE";
					cin>>x;
					
					cout<<"ENTER BOOK TITLE ";
					cin>>tit;
					cout<<"\n";
					cout<<"ENTER BOOK AUTHOR ";
					cin>>auth;
					cout<<"\n";
					cout<<"ENTER BOOK PUBLISHER ";
					cin>>pub;
					cout<<"\n";
					cout<<"ENTER BOOK PRICE ";
					cin>>price;
					cout<<"\n";
					cout<<"ENTER AVAILABLE STOCK ";
					cin>>stock;
					cout<<"\n";
		         	b[x] = new Book(tit,auth,pub,price,stock);
			 		 break;
			case 4 :;break;
			case 5 :;break;
			case 6 :;break;
			case 7: break;
		}
		
	}
	while(m!=6);
	return 0;
}
