#include <iostream>
#include<fstream>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
class student
{
 int rollno;
 char name[20];
 float pr;
 float pm;
 public:
     void Read()
     {
       cout<<"\n\n Enter rollno:";
       cin>>rollno;
       cout<<"\n Enter name:";
       cin>>name;
       cout<<"\n Enter percentage attendance:";
       cin>>pr;
       cout<<"\n Enter percentage marks:";
       cin>>pm;
       }
    void display()
    {
     cout<<"\n ROLL_NO.:";
     cout<<rollno;
     cout<<"\n NAME:";
     cout<<name;
     cout<<"\n Percentage attendance:"<<pr<<"\n percentage marks:"<<pm;
     cout<<"\n";
    }
int x()
{
    return rollno;
}
};
main()
{
  student object;
  ofstream foutfile;
  ifstream finfile;
  int i,j,k;
  int ch;
  char chk='y';
  int n;
     do
     {
    cout<<"\n Press 1 for creating database";
    cout<<"\n Press 2 to display database";
    cout<<"\n Press 3 to add a record";
    cout<<"\n Press 4 to delete a record";
    cout<<"\n Press 5 to modify a record\n";
    cin>>ch;
     switch(ch)
     {
           case 1:
               foutfile.open("AIT.txt", ios::in);
            cout<<"\n Enter the no. of records:";
            cin>>n;
            for(i=0;i<n;i++)
          {
              cout<<"\nEnter record for person "<<i+1;
              object.Read();
              foutfile.write((char *)&object,sizeof(object));
          }
          foutfile.close();
           break;
    case 2:
            finfile.open("AIT.txt",ios::out);
            finfile.read((char*)&object, sizeof(object));
	              	while(!finfile.eof())
	            	{
	        		object.display();
                      finfile.read((char*)&object, sizeof(object));
		           }
	             finfile.close();
	             break;
    case 3:
	          foutfile.open("AIT.txt",ios::app| ios::in);
	            while(chk=='y' || chk =='Y')
	           {
	         	object.Read();
	          	foutfile.write((char*)&object, sizeof(object));
	            	cout<<"\nAdd another record?\n";
	          	cin>>chk;
	          	n++;
	          }
	          foutfile.close();
                break;
   case 4:
            printf("\n Enter the roll no. whose record you want to delete:");
             scanf("%d",&k);
              foutfile.open ("temp.bin",ios::in|ios::out);
              finfile.open ("AIT.txt",ios::in|ios::out);
             while(finfile.read((char*)&object,sizeof(object)))
            {
                if(object.x()!=k)
              {
                  foutfile.write((char*)&object,sizeof(object));
                  n++;
              }
            }
            finfile.close();
            foutfile.close();
            remove("AIT.txt");
            rename("temp.bin","student.bin");
            break;
   case 5:   printf("\n Enter the roll no. whose record you want to modify");
             scanf("%d",&k);
             fstream f;
             int z;
             f.open ("AIT.txt",ios::in|ios::out);
             while(f.read((char*)&object,sizeof(object)))
             {
                  if(object.x()==k)
                {
                f.seekg(0,ios::cur);
				cout<<"Enter New Record.."<<endl;
				object.Read();
				f.seekp(f.tellg() - sizeof(object));
				f.write((char*)&object, sizeof(object));
                f.close();
                }
             }
     }
   }while(ch<6);
}
